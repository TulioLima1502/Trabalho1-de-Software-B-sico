// stdafx.cpp : arquivo de origem que inclui apenas as inclusões padrões
// $safeprojectname$.pch será o cabeçalho pré-compilado
// stdafx.obj conterá as informações de tipo pré-compiladas

#include "stdafx.h"

// TODO: referencie qualquer cabeçalho adicional necessário em STDAFX.H
// e não neste arquivo
