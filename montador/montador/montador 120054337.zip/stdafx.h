// stdafx.h : arquivo de inclusão para inclusões do sistema padrões,
// ou inclusões específicas de projeto que são utilizadas frequentemente, mas
// são modificadas raramente
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>



// TODO: adicionar referências de cabeçalhos adicionais que seu programa necessita
