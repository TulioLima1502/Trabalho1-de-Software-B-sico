#pragma once

// Incluir SDKDDKVer.h define a plataforma Windows mais alta disponível.

// Se você deseja compilar sua aplicação para versões anteriores de plataformas Windows, inclua WinSDKVer.h e
// ajuste a macro _WIN32_WINNT para a plataforma que você deseja suportar antes de incluir SDKDDKVer.h.

#include <SDKDDKVer.h>
